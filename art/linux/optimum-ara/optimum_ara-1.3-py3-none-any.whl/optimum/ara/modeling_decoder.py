# Copyright (c) 2025, Kinara, Inc. All rights reserved.

import os
from copy import deepcopy
from pathlib import Path
from typing import Optional, Union

import numpy as np
import ctypes as c

import torch
from transformers import AutoModelForCausalLM
from transformers.generation import GenerationMixin
from transformers.generation.configuration_utils import GenerationConfig
from transformers.generation.streamers import BaseStreamer

from .api import dvapi
from .api.dvapi import DVModel, DVSession, dv_status_code
from .api.exceptions import DvApiException
from .configuration_utils import AraConfig, AraPretrainedConfig
from .generation.configuration_utils import AraGenerationConfig, AraHostConfig
from .modeling_base import AraModel
from .utils.constants import DEFAULT_GENERATION_CONFIG_NAME
from .utils.file_utils import find_files_matching_pattern


class AraModelForCausalLM(AraModel, GenerationMixin):
    """
    AraModelForCausalLM is a wrapper for causal language modeling using Ara models.
    """

    auto_model_class = AutoModelForCausalLM
    main_input_name = "input_ids"
    stateful = False
    pad_token_id = 0

    def __init__(
        self,
        session,
        model,
        endpoint,
        model_path: Union[Path, str],
        config: "AraPretrainedConfig",
        generation_config: Optional["AraGenerationConfig"] = None,
        preprocessors: Optional[list] = None,
        use_cache: Optional[bool] = True,
        **kwargs,
    ):
        """
        Initialize the AraModelForCausalLM.

        Args:
            session: DVSession object for model execution.
            model: DVModel object representing the loaded model.
            endpoint: Endpoint for model inference.
            model_path (Union[Path, str]): Path to the model file.
            config (AraPretrainedConfig): Model configuration.
            generation_config (Optional[AraGenerationConfig]): Generation configuration.
            preprocessors (Optional[list]): List of preprocessors.
            use_cache (Optional[bool]): Whether to use KV caching.
            **kwargs: Additional keyword arguments.
        """
        super().__init__(
            session=session,
            model=model,
            endpoint=endpoint,
            model_path=model_path,
            config=config,
            preprocessors=preprocessors,
        )
        self.normalized_config = None
        self.num_pkv = 2
        self.use_cache = use_cache
        self.next_token_idx = 0
        # self.key_value_input_names = [
        #     key for key in self.input_names if (".key" in key) or (".value") in key
        # ]

        if generation_config is None:
            generation_config = AraGenerationConfig.from_model_config(config)

        self.generation_config = generation_config
        self.dvm_paths = [self.model_path]
        self.model_type = self.config.model_type

        self.key_value_input_names = []  # need to be populated for KV-caching
        self.key_value_output_names = []  # need to populated for KV-caching

        # TODO: figure out what merged_decoders are -- implement handling

        self.use_merged = False  # keeping this false for now
        self.use_fp16 = False  # keeping this hardcoded for now

    @classmethod
    def _load_model(
        cls,
        model_path: Union[str, Path],
        config: AraConfig,
        session: DVSession,
        endpoint: dvapi.dv_endpoint,
        generation_config: Optional[AraGenerationConfig] = None,
    ) -> DVModel:
        """
        Loads a DVM model from file with the specified options and updates its generation config.

        Args:
            model_path (Union[str, Path]): Path to the model file.
            config (AraConfig): Model configuration.
            session (DVSession): DVSession object.
            endpoint (dvapi.dv_endpoint): Endpoint for inference.
            generation_config (Optional[AraGenerationConfig]): Generation configuration.

        Returns:
            DVModel: Loaded model object.
        """
        if isinstance(model_path, Path):
            model_path = str(model_path)

        model_load_options: dvapi.DVModelLoadOptions = (
            dvapi.DVModelLoadOptions.model_load_option(
                model_name="llm_model",
                priority=dvapi.dv_model_priority_level.DV_MODEL_PRIORITY_LEVEL_DEFAULT,
                cache=False,
                model_async=False,
                model_type=dvapi.dv_model_type.DV_MODEL_TYPE_ARA2_LLM_DYN_V2,
            )
        )
        ret, model = session.load_model_from_file_with_options(
            endpoint, model_path, options=model_load_options
        )
        if ret != dvapi.dv_status_code.DV_SUCCESS:
            raise DvApiException(
                f"Could not load model: {dvapi.dv_stringify_status_code(ret)}"
            )

        if generation_config:
            llm_cfg_update: dvapi.DVLLMModelCfgUpdateParams = (
                dvapi.DVLLMModelCfgUpdateParams.llm_model_cfg_options(
                    top_k=generation_config.top_k,
                    top_p=generation_config.top_p,
                    temperature=generation_config.temperature,
                    repetition_penalty=generation_config.repetition_penalty,
                    target_token_post_mcp=generation_config.ara.target_token_post_mcp,
                    target_token_pre_mcp=generation_config.ara.target_token_pre_mcp,
                    target_prompt_post_mcp=generation_config.ara.target_prompt_post_mcp,
                    target_prompt_pre_mcp=generation_config.ara.target_prompt_pre_mcp,
                )
            )  # the option values to be passed are same as default values of ip args
        else:
            llm_cfg_update: dvapi.DVLLMModelCfgUpdateParams = (
                dvapi.DVLLMModelCfgUpdateParams.llm_model_cfg_options()
            )

        ret = dvapi.dv_model_set_llm_cfg_params(
            session=session._session,
            endpoint=endpoint._endpoint,
            model=model._model,
            llm_cfg_update=llm_cfg_update._llm_config_options,
        )
        if ret != dvapi.dv_status_code.DV_SUCCESS:
            raise DvApiException(
                f"Could not load LLM params to DV model: {dvapi.dv_stringify_status_code(ret)}"
            )

        assert model is not None
        return model

    def prepare_past_key_values(
        self,
        input_ids: np.ndarray,
        past_key_values: Union[None, tuple[tuple[np.ndarray]]],
        use_torch: bool = False,
    ):
        sequence_length = input_ids.shape[1]

        constructor = np  # only want to support numpy arrays
        # might need to change to support custom array wrapper

        # should probably not be needed
        if self.use_merged:
            # Uses without/with branch of a merged decoder depending
            # on whether real past key values are passed
            use_cache_branch = constructor.full((1,), past_key_values is not None)
        else:
            # Uses separate decoders
            use_cache_branch = None

        pkv_output_shape = {}

        # Generate dummy past for the first forward if uses a merged decoder
        if past_key_values is None:
            batch_size = input_ids.shape[0]
            embed_size_per_head = (
                self.config.hidden_size // self.config.num_attention_heads
            )

            # I removed handling of models other than Llama for now
            # will need to add back conditions for model type later

            dtype = constructor.float16 if self.use_fp16 else constructor.float32

            #! I removed control flow for specific model classes (like BloomForCausalLM)
            #! will need to add back later

            num_key_value_heads = self.config.num_key_value_heads

            shape = (batch_size, num_key_value_heads, 0, embed_size_per_head)
            key_or_value = constructor.zeros(shape, dtype=dtype)

            # can't do a KV-cache because can't get the input names from compiled
            # dvm file. Hence making this code unreachable for now
            if False:
                past_key_values = tuple(
                    key_or_value for _ in range(len(self.key_value_input_names))
                )

                for name, value in zip(self.key_value_output_names, past_key_values):
                    shape = [*value.shape]
                    shape[2] += sequence_length
                    pkv_output_shape[name] = shape

        return use_cache_branch, past_key_values, pkv_output_shape

    # def forward(
    #     self,
    #     input_ids: np.ndarray,
    #     attention_mask: Optional[np.ndarray] = None,
    #     position_ids: Optional[np.ndarray] = None,
    #     past_key_values: Optional[tuple[tuple[np.ndarray]]] = None,
    #     use_cache_branch: bool = False,
    #     token_type_ids: Optional[np.ndarray] = None,
    #     **kwargs,
    # ):
    #     raise NotImplementedError(
    #         "Calling forward function directly is not currently supported"
    #     )

    def prepare_inputs_for_generation(
        self, input_ids: np.ndarray, generation_config: AraGenerationConfig
    ) -> dict[str, np.ndarray]:
        """
        Prepares input and output arrays for generation.

        Args:
            input_ids (np.ndarray): Input token IDs.
            generation_config (AraGenerationConfig): Generation configuration.

        Returns:
            dict: Dictionary with input and output arrays.
        """
        # num_embeddings_per_token = self.config.max_position_embeddings
        num_max_tokens = generation_config.max_length
        # vocab_size = self.config.vocab_size

        input_array = np.zeros(num_max_tokens, dtype=np.int32)
        output_array = np.zeros(num_max_tokens, dtype=np.int32)
        # token_history = np.zeros(num_max_tokens, dtype=np.int64)

        num_tokens = input_ids.size
        input_array[:num_tokens] = input_ids.flatten()
        input_array[num_tokens:] = generation_config.pad_token_id

        # prompt_processing_input = np.zeros((num_max_tokens, num_embeddings_per_token))
        # prompt_processing_scale_input = np.empty(
        #     (num_max_tokens, int(num_embeddings_per_token / 64)),
        #     dtype=np.int8,
        # )
        # logits_output: np.ndarray = np.zeros(vocab_size, dtype=np.int32)

        return {
            "input_array": input_array,
            "output_array": output_array,
        }

    def _generate_first_token(
        self,
        input_array: np.ndarray,
        output_array: np.ndarray,
        num_valid_tokens: int,
        next_token_index: int,
        generation_config: Optional[GenerationConfig] = None,
    ) -> dv_status_code:
        """
        Generates the first token using prompt processing.

        Args:
            input_array (np.ndarray): Input array.
            output_array (np.ndarray): Output array.
            num_tokens (int): Number of tokens in the prompt.

        Returns:
            dv_status_code: Status code of the inference.
        """
        endpoint = self.endpoint

        status, inf_req_obj = self.forward(
            input_array,
            output_array,
            infer_type=dvapi.dv_infer_type.DV_INFER_TYPE_LLM_PROMPT_PROCESSING,
            active_tokens=next_token_index,
            valid_tokens=num_valid_tokens,
        )

        return status

    def _generate_next_token(
        self,
        input_array: np.ndarray,
        output_array: np.ndarray,
        num_valid_tokens: int,
        next_token_index: int,
        generation_config: Optional[GenerationConfig] = None,
    ):
        """
        Generates the next token(s) using token generation inference.

        Args:
            input_array (np.ndarray): Input array.
            output_array (np.ndarray): Output array.
            num_valid_tokens (int): Number of valid tokens.
            next_token_index (int): Index for the next token.

        Returns:
            Tuple of status code and inference request object.
        """
        endpoint = self.endpoint

        status, inf_req_obj = self.forward(
            input_array,
            output_array,
            infer_type=dvapi.dv_infer_type.DV_INFER_TYPE_LLM_TOKEN_GENERATION,
            active_tokens=next_token_index,
            valid_tokens=num_valid_tokens,
        )

        return status, inf_req_obj

    def _prepare_generation_config(
        self,
        generation_config: Optional[AraGenerationConfig],
        use_model_defaults=True,
        **kwargs,
    ) -> tuple[AraGenerationConfig, dict]:
        """
        Updates the generation configuration according to generation config or kwargs sent by the user

        Args:
            generation_config (Optional[AraGenerationConfig]): Generation configuration.
            **kwargs: Additional generation parameters.

        Returns:
            AraGenerationConfig: Updated generation configuration.
        """
        gen_config = deepcopy(self.generation_config)
        if generation_config:
            for key, value in generation_config.to_dict().items():
                setattr(gen_config, key, value)

        for key, value in kwargs.items():
            if key in AraHostConfig.model_fields.keys():
                setattr(gen_config.ara, key, value)
            elif key in gen_config.__dict__.keys():
                setattr(gen_config, key, value)
        return gen_config, kwargs

    def _update_llm_params(self, generation_config: AraGenerationConfig) -> None:
        """
        Updates the DV model's parameters according to the generation config.

        Args:
            generation_config (AraGenerationConfig): Generation configuration.
        """
        llm_cfg_update: dvapi.DVLLMModelCfgUpdateParams = (
            dvapi.DVLLMModelCfgUpdateParams.llm_model_cfg_options(
                top_k=generation_config.top_k,
                top_p=generation_config.top_p,
                temperature=generation_config.temperature,
                repetition_penalty=generation_config.repetition_penalty,
                target_token_post_mcp=generation_config.ara.target_token_post_mcp,
                target_token_pre_mcp=generation_config.ara.target_token_pre_mcp,
                target_prompt_post_mcp=generation_config.ara.target_prompt_post_mcp,
                target_prompt_pre_mcp=generation_config.ara.target_prompt_pre_mcp,
            )
        )  # the option values to be passed are same as default values of ip args
        ret = dvapi.dv_model_set_llm_cfg_params(
            session=self.session._session,
            endpoint=self.endpoint._endpoint,
            model=self.model._model,
            llm_cfg_update=llm_cfg_update._llm_config_options,
        )
        if ret != dvapi.dv_status_code.DV_SUCCESS:
            raise DvApiException(
                f"Could not load LLM params to DV model: {dvapi.dv_stringify_status_code(ret)}"
            )

    def generate(
        self,
        inputs: Optional[torch.Tensor] = None,
        generation_config: Optional[AraGenerationConfig] = None,
        input_ids: Optional[Union[torch.Tensor, list]] = None,
        streamer: Optional["BaseStreamer"] = None,
        **kwargs,
    ):
        """
        Generates text sequences given input tokens.

        Args:
            inputs (Optional[torch.Tensor]): Input tensor.
            generation_config (Optional[AraGenerationConfig]): Generation configuration.
            input_ids (Optional[Union[torch.Tensor, list]]): Input IDs.
            streamer (Optional[BaseStreamer]): Streamer for output tokens.
            **kwargs: Additional generation parameters.

        Returns:
            torch.Tensor: Generated token IDs.
        """
        if input_ids is not None:
            inputs = input_ids

        if isinstance(inputs, torch.Tensor):
            numpy_inputs = inputs.detach().numpy()
        elif isinstance(inputs, list):
            numpy_inputs = np.array(inputs)
        else:
            numpy_inputs = inputs

        # updates generation variables according to the generation config sent or kwargs
        generation_config, _ = self._prepare_generation_config(
            generation_config, **kwargs
        )

        self._update_llm_params(generation_config)

        num_max_tokens = generation_config.max_length
        if ( numpy_inputs.size  >= num_max_tokens):
            print(f"input lenght is greater than or equal to max token lentht {num_max_tokens}")
            return []
                

        eos_token_ls = (
            generation_config.eos_token_id
            if isinstance(generation_config.eos_token_id, list)
            else [generation_config.eos_token_id]
        )

        assert numpy_inputs is not None, "`numpy_inputs` can not be None"
        prepared_inputs = self.prepare_inputs_for_generation(
            numpy_inputs, generation_config
        )

        num_tokens = numpy_inputs.size
        next_token_index = num_tokens
        
        input_array = prepared_inputs["input_array"]
        output_array = prepared_inputs["output_array"]

        generated_list = []
        active_tokens = num_tokens
        num_valid_tokens = num_tokens

        # Measure Time to First Token (TTFT)
        import time
        ttft_start = time.time()
        status = self._generate_first_token(input_array, output_array, active_tokens, num_valid_tokens)
        ttft = time.time() - ttft_start

        # Store TTFT for later access
        self._ttft = ttft
        self._subsequent_start = time.time()

        if status != dv_status_code.DV_SUCCESS:
            raise DvApiException(
                "Failed to generate first token",
                f"{dvapi.dv_stringify_status_code(status)}",
            )

        # print("[DEBUG] first token generated")
        num_valid_tokens = 1
        valid_tokens = output_array[:num_valid_tokens].copy()

        generated_list += valid_tokens.flatten().tolist()

        num_tokens += 1
        next_token_index += 1

        if streamer is not None:
            streamer.put(valid_tokens)

        while True:
            if (
                len(generated_list) + numpy_inputs.size  >= num_max_tokens
                or any(token in eos_token_ls for token in valid_tokens)
            ):
                break

            input_array = np.pad(
                valid_tokens,
                (0, 4 - len(valid_tokens)),
                "constant",
                constant_values=valid_tokens[0],
            )

            status, inf_req = self._generate_next_token(
                input_array=input_array,
                output_array=output_array,
                num_valid_tokens=num_valid_tokens,
                next_token_index=next_token_index - num_valid_tokens,
            )
            # print("[DEBUG] next token generated")
            if status != dv_status_code.DV_SUCCESS:
                raise DvApiException(
                    "Next token generation failed",
                    f"{dvapi.dv_stringify_status_code(status)}",
                )

            assert inf_req is not None

            num_valid_tokens = (
                inf_req.contents.llm_infer_info.contents.llm_infer_resp_num_valid_tokens
            )
            # print(f"[DEBUG] {num_valid_tokens=}")
            
            # Check if we got any valid tokens
            if num_valid_tokens == 0:
                # No more tokens generated, break the loop
                break

            valid_tokens = output_array[:num_valid_tokens]
            next_token_index += len(valid_tokens)

            if streamer is not None:
                streamer.put(valid_tokens)

            for token in valid_tokens:
                if token in eos_token_ls:
                    if streamer is not None:
                        streamer.end()
                    break
                generated_list.append(token)

        self._token_generation_time = time.time() - self._subsequent_start
        self._generated_tokens_count = len(generated_list)
        return generated_list

    def _reorder_cache(self, past_key_values, beam_idx):
        raise NotImplementedError

    def get_generation_timing(self):
        """
        Get timing information from the last generation.

        Returns:
            dict: Dictionary containing ttft, total_time, and calculated token_rate
        """
        if not hasattr(self, '_ttft') or not hasattr(self, '_subsequent_start'):
            return None

        import time
        total_time = time.time() - (self._subsequent_start - self._ttft)

        # Get the number of tokens generated (excluding input tokens)
        # This is a rough estimate - we'd need to track this more precisely
        # For now, we'll return the timing info and let the caller calculate the rate

        return {
            'ttft': self._ttft,
            'total_time': total_time,
            'subsequent_time': total_time - self._ttft
        }
    
    def display_perf_statistics(self):
        """
        print performance statistics
        
        Returns:
            None
        """
        token_rate = 0
        if self._token_generation_time > 0:
            token_rate = (self._generated_tokens_count - 1)/self._token_generation_time
        print('############### Performance Statistics #################')
        print('Time to first token (TTFT)     :', str(round(self._ttft,2)) + ' sec' )
        print('Generation time (without TTFT) :', str(round(self._token_generation_time,2)) + ' sec' )
        print('Number of tokens generated     :', str(round(self._generated_tokens_count,2)) + ' tokens' )
        print('token rate                     :', str(round(token_rate,2)) + ' tokens/sec' )
        print('\n')

    @classmethod
    def from_pretrained(
        cls,
        model_id: Union[str, Path],
        config: Optional["AraPretrainedConfig"] = None,
        token: Optional[Union[bool, str]] = None,
        # revision: Optional[str] = None,
        force_download: bool = False,
        # cache_dir: str = HUGGINGFACE_HUB_CACHE,
        file_name: Optional[str] = None,
        subfolder: str = "",
        use_cache: bool = True,
        local_files_only: bool = False,
        use_merged: Optional[bool] = None,
        # provider: str = "CPUExecutionProvider",
        # session_options: Optional[onnxruntime.SessionOptions] = None,
        # provider_options: Optional[Dict[str, Any]] = None,
        # use_io_binding: Optional[bool] = None,
        # model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        **kwargs,
    ) -> "AraModelForCausalLM":
        """
        Loads a pretrained AraModelForCausalLM from disk.

        Args:
            model_id (Union[str, Path]): Model identifier or path.
            config (Optional[AraPretrainedConfig]): Model configuration.
            token (Optional[Union[bool, str]]): Token for authentication.
            file_name (Optional[str]): Specific model file name.
            subfolder (str): Subfolder containing the model.
            use_cache (bool): Whether to use KV caching.
            use_merged (Optional[bool]): Use merged decoder.
            **kwargs: Additional arguments.

        Returns:
            AraModelForCausalLM: Loaded model instance.
        """
        generation_config = kwargs.pop("generation_config", None)
        # We do not implement the logic for use_cache=False, use_merged=True
        if use_cache is False:
            if use_merged is True:
                raise ValueError(
                    "The parameters combination use_cache=False, use_merged=True"
                    "is not supported. To use a merged decoder, past key values"
                    "must be used."
                )
            use_merged = False

        if not os.path.exists(model_id) and not file_name and not config:
            raise ValueError(
                "Can not make an AraModel class without a dvm file."
                "Have to pass one of the following:\n{\nmodel_id: local_folder_path, \nfile_name: local_dvm_file, \nconfig: AraPretrainedConfig\n}"
            )

        if os.path.exists(model_id):
            # Check if model_id is a specific .dvm file
            if model_id.endswith(".dvm"):
                dvm_files = [Path(model_id)]
            else:
                # If it's a directory, search for .dvm files (legacy behavior)
                dvm_files = find_files_matching_pattern(
                    model_id,
                    r".*\.dvm",
                    glob_pattern="**/*.dvm",
                    subfolder=subfolder,
                )
        elif file_name and os.path.exists(file_name) and file_name.endswith(".dvm"):
            # checks if user's file name is a model.dvm file and it exists.
            dvm_files = [Path(file_name)]
        elif config and "ara" in config:
            # checks if the config passed by the user has a correct dvm path.
            dvm_files = [Path(config.ara.dvm_path)]
        else:
            raise FileNotFoundError(f"Could not find any DVM model file")

        if len(dvm_files) == 0:
            raise FileNotFoundError(f"Could not find any DVM model file in {model_id}")
        if len(dvm_files) == 1:
            pass
        else:
            raise NotImplementedError(
                "handling of more than one dvm file in folder is not supported"
            )

        init_cls = cls

        # if user had not passed config, try to load it from the model folder or from hugging face
        if not config:
            config = AraPretrainedConfig.from_pretrained(
                model_id, dvm_path=str(dvm_files[0])
            )

        generation_config_path = Path(
            os.path.join(model_id, DEFAULT_GENERATION_CONFIG_NAME)
        )
        # if user had not passed generation_config, try to load it from the model folder
        if not generation_config:
            # if generation config path does not exist, load it from the model config
            if not generation_config_path.exists():
                hf_model_id = config._name_or_path
                generation_config = AraGenerationConfig.from_pretrained(hf_model_id)
            else:
                generation_config = AraGenerationConfig.from_json_file(
                    generation_config_path
                )

        session, endpoint, model = cls.load_model(
            dvm_files[0].resolve(), config.ara, generation_config
        )

        return init_cls(
            session=session,
            model=model,
            endpoint=endpoint,
            model_path=dvm_files[0],
            config=config,
            generation_config=generation_config,
            use_cache=use_cache,
            kwargs=kwargs,
        )

    @classmethod
    def from_config(cls, config: AraPretrainedConfig, **kwargs):
        """
        Instantiates the model from a model configuration object.

        Args:
            config (AraPretrainedConfig): Model configuration.
            **kwargs: Additional arguments.

        Returns:
            AraModelForCausalLM: Loaded model instance.
        """
        model_id = config.ara.dvm_path
        return cls.from_pretrained(model_id, config=config, **kwargs)

    @classmethod
    def _from_config(cls, config: AraPretrainedConfig, **kwargs):
        return cls.from_config(config, **kwargs)

    def save_config(self, save_directory):
        """
        Saves the model configuration to the specified directory.

        Args:
            save_directory (str): Directory to save the configuration.
        """
        os.makedirs(save_directory, exist_ok=True)

        self.config.save_pretrained(save_directory)
        # TODO Add gen config saving option here as well
