# Copyright (c) 2025, Kinara, Inc. All rights reserved.

import os
import re
from pathlib import Path
from typing import List, Optional, Union


def find_files_matching_pattern(
    model_name_or_path: Union[str, Path],
    pattern: str,
    glob_pattern: str = "**/*",
    subfolder: str = "",
    revision: Optional[str] = None,
) -> List[Path]:
    """
    Scans either a model repo or a local directory to find filenames matching the pattern.

    Args:
        model_name_or_path (`Union[str, Path]`):
            The name of the model repo on the Hugging Face Hub or the path to a local directory.
        pattern (`str`):
            The pattern to use to look for files.
        glob_pattern (`str`, defaults to `"**/*"`):
            The pattern to use to list all the files that need to be checked.
        subfolder (`str`, defaults to `""`):
            In case the model files are located inside a subfolder of the model directory / repo on the Hugging
            Face Hub, you can specify the subfolder name here.
        use_auth_token (`Optional[Union[bool,str]]`, defaults to `None`):
            Deprecated. Please use the `token` argument instead.
        token (`Optional[Union[bool,str]]`, defaults to `None`):
            The token to use as HTTP bearer authorization for remote files. If `True`, will use the token generated
            when running `huggingface-cli login` (stored in `huggingface_hub.constants.HF_TOKEN_PATH`).
        token (`Optional[Union[bool, str]]`, *optional*):
            The token to use as HTTP bearer authorization for remote files. If `True`, will use the token generated
            when running `transformers-cli login` (stored in `~/.huggingface`).
        revision (`Optional[str]`, defaults to `None`):
            Revision is the specific model version to use. It can be a branch name, a tag name, or a commit id.

    Returns:
        `List[Path]`
    """

    model_path = (
        str(model_name_or_path)
        if isinstance(model_name_or_path, Path)
        else model_name_or_path
    )
    pattern = re.compile(subfolder + pattern)
    if os.path.isdir(model_path):
        files = Path(model_path).glob(glob_pattern)
        files = [p for p in files if re.search(pattern, str(p))]
    elif os.path.isfile(model_path) and re.search(pattern, str(model_path)):
        files = [Path(model_path)]
    else:
        raise NotImplementedError

    return files
