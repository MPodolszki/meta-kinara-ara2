# Copyright (c) 2025, Kinara, Inc. All rights reserved.

import logging

LOG_FORMAT = "[%(levelname)s] [%(filename)s:%(funcName)s] %(message)s"
LOG_LEVEL = "INFO"

def get_logger(name: str = __name__) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, LOG_LEVEL))

    if not logger.handlers:
        ch = logging.StreamHandler()
        ch.setLevel(getattr(logging, LOG_LEVEL))

        formatter = logging.Formatter(LOG_FORMAT)
        ch.setFormatter(formatter)

        logger.addHandler(ch)
        logger.propagate = False  # Avoid duplicate logs in root logger

    return logger
