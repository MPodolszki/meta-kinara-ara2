# Copyright (c) 2025, Kinara, Inc. All rights reserved.

import logging
import sys

logger = logging.getLogger(__name__)


def signal_handler(llm_app, signum, frame):
    if llm_app.llm_session:
        llm_app.llm_session.close_llmapp_session()
    logger.info("You pressed Ctrl+C!")
    sys.exit(1)


class exit_handler(logging.StreamHandler):

    # TODO add continue on error and stop after N errors
    def emit(self, record):
        super().emit(record)
        if record.levelno in (logging.ERROR, logging.CRITICAL):
            print("calling sys.exit")
            logging.shutdown()
            sys.exit(1)


def setup_logger(log_level="info"):
    log_level_map = {
        "debug": logging.DEBUG,
        "info": logging.INFO,
        "warn": logging.WARNING,
        "error": logging.ERROR,
    }
    if log_level.lower() in log_level_map.keys():
        logging.disable(logging.NOTSET)
        logging.basicConfig(
            handlers=[exit_handler()],
            format="[%(levelname).1s:%(asctime)s:%(msecs)03d] [%(name)s] %(message)s",
            level=log_level_map[log_level.lower()],
            datefmt="%y%m%d:%H%M%S",
            force=True,
        )
        logger = logging.getLogger("LLMAPP")
        return logger
    else:
        sys.exit("log level should be one of debug|info|warn|error")
