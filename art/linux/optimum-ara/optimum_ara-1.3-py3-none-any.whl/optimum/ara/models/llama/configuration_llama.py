# Copyright (c) 2025, Kinara, Inc. All rights reserved.

from ...configuration_utils import AraPretrainedConfig


class AraLlamaConfig(AraPretrainedConfig):
    model_type = "ara_llama"
    config_class = AraPretrainedConfig
    pass
