# Copyright (c) 2025, Kinara, Inc. All rights reserved.

from ...modeling_decoder import AraModelForCausalLM
from .configuration_llama import AraLlamaConfig


class AraLlamaForCausalLM(AraModelForCausalLM):
    config_class = AraLlamaConfig
    pass
