# Copyright (c) 2025, Kinara, Inc. All rights reserved.

from transformers import AutoConfig, AutoModelForCausalLM

from .configuration_llama import AraLlamaConfig
from .modeling_llama import AraLlamaForCausalLM

AutoConfig.register("ara_llama", AraLlamaConfig)
AutoModelForCausalLM.register(AraLlamaConfig, AraLlamaForCausalLM)
