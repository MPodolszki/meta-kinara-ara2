# Copyright (c) 2025, Kinara, Inc. All rights reserved.

from ...modeling_decoder import AraModelForCausalLM
from .configuration_qwen import AraQwenConfig


class AraQwenForCausalLM(AraModelForCausalLM):
    config_class = AraQwenConfig
    pass
