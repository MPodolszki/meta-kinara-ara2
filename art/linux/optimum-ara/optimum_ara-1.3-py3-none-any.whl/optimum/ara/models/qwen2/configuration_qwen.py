# Copyright (c) 2025, Kinara, Inc. All rights reserved.

from ...configuration_utils import AraPretrainedConfig


class AraQwenConfig(AraPretrainedConfig):
    model_type = "ara_qwen"
    config_class = AraPretrainedConfig
    pass
