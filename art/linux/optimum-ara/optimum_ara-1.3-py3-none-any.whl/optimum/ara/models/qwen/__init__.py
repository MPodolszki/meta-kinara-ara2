# Copyright (c) 2025, Kinara, Inc. All rights reserved.

from transformers import AutoConfig, AutoModelForCausalLM

from .configuration_qwen import AraQwenConfig
from .modeling_qwen import AraQwenForCausalLM

# Register with transformers library for seamless HF integration
AutoConfig.register("ara_qwen", AraQwenConfig)
AutoModelForCausalLM.register(AraQwenConfig, AraQwenForCausalLM)

__all__ = [
    "AraQwenConfig",
    "AraQwenForCausalLM",
]