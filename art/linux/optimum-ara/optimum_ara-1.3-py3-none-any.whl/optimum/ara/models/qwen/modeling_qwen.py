# Copyright (c) 2025, Kinara, Inc. All rights reserved.

import os
from pathlib import Path
from typing import Optional, Union, List, Dict, Any, Tuple

import numpy as np
import torch
from PIL import Image
from transformers import AutoProcessor

from ...api import dvapi
from ...api.dvapi import DVModel, DVSession, dv_status_code
from ...api.exceptions import DvApiException
from ...configuration_utils import AraConfig
from ...generation.configuration_utils import AraGenerationConfig
from ...modeling_visual_language import AraVisualLanguageModel
from .configuration_qwen import AraQwenConfig


class AraQwenForCausalLM(AraVisualLanguageModel):
    """
    Ara Qwen VLM model for vision-language tasks.

    This model follows the same flow as LLaVA:
    1. Vision encoder processes images and outputs features
    2. Language model handles text generation with merged image+text embeddings

    The models are automatically loaded from the paths specified in the config.
    """

    config_class = AraQwenConfig
    auto_model_class = None  # Will be set during registration

    def _setup_processors(self):
        """Setup image and text processors for Qwen VLM."""
        try:
            # Try to load processors from the model directory
            model_dir = str(self.model_path.parent)
            if os.path.exists(os.path.join(model_dir, "processor_config.json")):
                self.image_processor = AutoProcessor.from_pretrained(model_dir)
                self.text_processor = self.image_processor
            else:
                # Fallback to Qwen VLM processor
                self.image_processor = AutoProcessor.from_pretrained("Qwen/Qwen2.5-VL-7B")
                self.text_processor = self.image_processor
        except Exception as e:
            print(f"Warning: Could not load processors: {e}")
            self.image_processor = None
            self.text_processor = None

    @classmethod
    def _load_model(
        cls,
        model_path: Union[str, Path],
        config: AraConfig,
        session: DVSession,
        endpoint: dvapi.dv_endpoint,
        generation_config: Optional[AraGenerationConfig] = None,
    ) -> DVModel:
        """
        Loads a Qwen VLM language model from file.

        Args:
            model_path (Union[str, Path]): Path to the model file.
            config (AraConfig): Model configuration.
            session (DVSession): Session for model loading.
            endpoint (dvapi.dv_endpoint): Endpoint for model loading.
            generation_config (Optional[AraGenerationConfig]): Generation configuration.

        Returns:
            DVModel: Loaded language model object.
        """
        # Load the language model (following demo pattern)
        model_load_options: dvapi.DVModelLoadOptions = (
            dvapi.DVModelLoadOptions.model_load_option(
                model_name="qwen_language_model",
                model_path=str(model_path),
                model_type=dvapi.DVModelType.DV_MODEL_TYPE_LLM,
            )
        )

        ret = session.load_model(model_load_options, endpoint)
        if ret != dv_status_code.DV_SUCCESS:
            raise RuntimeError(
                f"Could not load Qwen VLM language model: {dvapi.dv_stringify_status_code(ret)}"
            )

        # Load model parameters
        ret = session.load_model_params(model_load_options, endpoint)
        if ret != dv_status_code.DV_SUCCESS:
            raise RuntimeError(
                f"Could not load language model params: {dvapi.dv_stringify_status_code(ret)}"
            )

        return session.get_model(model_load_options)

    @classmethod
    def from_pretrained(
        cls,
        model_id: Union[str, Path],
        config: Optional["AraQwenConfig"] = None,
        token: Optional[Union[bool, str]] = None,
        force_download: bool = False,
        file_name: Optional[str] = None,
        subfolder: str = "",
        use_cache: bool = True,
        local_files_only: bool = False,
        use_merged: Optional[bool] = None,
        **kwargs,
    ) -> "AraQwenForCausalLM":
        """
        Load a pretrained Qwen VLM model.

        Args:
            model_id (Union[str, Path]): Model identifier or path.
            config (Optional[AraQwenConfig]): Model configuration.
            token (Optional[Union[bool, str]]): Token for authentication.
            file_name (Optional[str]): Specific model file name.
            subfolder (str): Subfolder containing the model.
            use_cache (bool): Whether to use KV caching.
            use_merged (Optional[bool]): Use merged decoder.
            **kwargs: Additional arguments.

        Returns:
            AraQwenForCausalLM: Loaded model instance.
        """
        # Use parent's from_pretrained method
        return super().from_pretrained(
            model_id=model_id,
            config=config,
            token=token,
            force_download=force_download,
            file_name=file_name,
            subfolder=subfolder,
            use_cache=use_cache,
            local_files_only=local_files_only,
            use_merged=use_merged,
            **kwargs,
        )