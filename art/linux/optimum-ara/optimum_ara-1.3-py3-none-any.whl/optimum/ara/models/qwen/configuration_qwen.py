# Copyright (c) 2025, Kinara, Inc. All rights reserved.

from ...configuration_utils import AraPretrainedConfig


class AraQwenConfig(AraPretrainedConfig):
    """
    Configuration class for Ara Qwen VLM models.

    This configuration extends AraPretrainedConfig with Qwen-specific parameters
    for vision-language modeling.
    """

    model_type = "ara_qwen"
    config_class = AraPretrainedConfig

    def __init__(
        self,
        # Vision encoder parameters
        vision_config=None,
        image_size=224,  # Qwen VLM default
        patch_size=14,   # Qwen VLM default
        num_channels=3,  # RGB
        hidden_size=1024,  # Qwen VLM hidden size
        intermediate_size=4096,
        num_hidden_layers=24,  # Qwen VLM layers
        num_attention_heads=16,
        hidden_act="quick_gelu",
        layer_norm_eps=1e-6,
        attention_dropout=0.0,
        initializer_range=0.02,
        # Language model parameters (Qwen 2.5)
        vocab_size=151936,
        max_position_embeddings=32768,
        num_key_value_heads=8,
        rope_theta=10000.0,
        use_cache=True,
        # Projection parameters
        projection_dim=4096,  # Qwen 2.5 hidden size
        # Multimodal parameters
        mm_vision_select_layer=-2,  # Use second-to-last layer
        mm_use_im_start_end=False,
        mm_use_im_patch_token=True,
        # DVM model paths (following demo pattern)
        vision_model_path=None,  # Path to ViT DVM model
        llm_model_path=None,     # Path to LLM DVM model
        # Generation parameters
        pad_token_id=0,
        bos_token_id=1,
        eos_token_id=2,
        tie_word_embeddings=False,
        **kwargs,
    ):
        super().__init__(**kwargs)

        # Vision encoder config
        self.vision_config = vision_config
        self.image_size = image_size
        self.patch_size = patch_size
        self.num_channels = num_channels
        self.hidden_size = hidden_size
        self.intermediate_size = intermediate_size
        self.num_hidden_layers = num_hidden_layers
        self.num_attention_heads = num_attention_heads
        self.hidden_act = hidden_act
        self.layer_norm_eps = layer_norm_eps
        self.attention_dropout = attention_dropout
        self.initializer_range = initializer_range

        # Language model config
        self.vocab_size = vocab_size
        self.max_position_embeddings = max_position_embeddings
        self.num_key_value_heads = num_key_value_heads
        self.rope_theta = rope_theta
        self.use_cache = use_cache

        # Projection config
        self.projection_dim = projection_dim

        # Multimodal config
        self.mm_vision_select_layer = mm_vision_select_layer
        self.mm_use_im_start_end = mm_use_im_start_end
        self.mm_use_im_patch_token = mm_use_im_patch_token

        # DVM model paths
        self.vision_model_path = vision_model_path
        self.llm_model_path = llm_model_path

        # Token config
        self.pad_token_id = pad_token_id
        self.bos_token_id = bos_token_id
        self.eos_token_id = eos_token_id
        self.tie_word_embeddings = tie_word_embeddings