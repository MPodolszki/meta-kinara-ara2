# Copyright (c) 2025, Kinara, Inc. All rights reserved.

from ...configuration_utils import AraPretrainedConfig


class AraLlavaConfig(AraPretrainedConfig):
    """
    Configuration class for LLaVA models.
    
    Inherits from AraPretrainedConfig and adds LLaVA-specific parameters.
    """
    
    model_type = "llava"
    
    def __init__(
        self,
        vision_model_path: str = None,
        embedding_table_path: str = None,
        num_max_tokens: int = 2048,
        num_embeddings_per_token: int = 4096,
        num_total_tokens: int = 128320,
        repetition_penalty: float = 1.12,
        pad_token_id: int = 128009,
        eos_token_id: int = 128009,
        bos_token_id: int = 128000,
        num_repeat_ngram_size: int = 2,
        ngram_panalty: int = 10,
        apply_repetition_penalty: bool = True,
        generation_mode: str = "greedy_search",
        temperature: float = 0.7,
        top_k: int = 40,
        top_p: float = 0.9,
        num_max_iterations: int = 2048,
        use_chat_template: bool = False,
        **kwargs,
    ):
        super().__init__(**kwargs)
        
        # LLaVA-specific parameters
        self.vision_model_path = vision_model_path
        self.embedding_table_path = embedding_table_path
        self.num_max_tokens = num_max_tokens
        self.num_embeddings_per_token = num_embeddings_per_token
        self.num_total_tokens = num_total_tokens
        self.repetition_penalty = repetition_penalty
        self.pad_token_id = pad_token_id
        self.eos_token_id = eos_token_id
        self.bos_token_id = bos_token_id
        self.num_repeat_ngram_size = num_repeat_ngram_size
        self.ngram_panalty = ngram_panalty
        self.apply_repetition_penalty = apply_repetition_penalty
        self.generation_mode = generation_mode
        self.temperature = temperature
        self.top_k = top_k
        self.top_p = top_p
        self.num_max_iterations = num_max_iterations
        self.use_chat_template = use_chat_template 