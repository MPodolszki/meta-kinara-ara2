# Copyright (c) 2025, Kinara, Inc. All rights reserved.

import os
from pathlib import Path
from typing import Optional, Union, Dict, Any

import numpy as np
import torch
from PIL import Image
from transformers import LlavaProcessor, GenerationConfig
from transformers.image_utils import get_image_size, to_numpy_array

from ...modeling_visual_language import AraModelForVisualCausalLM, quantize, dequantize
from ...api import dvapi
from ...api.dvapi import DVModel, DVSession, dv_status_code
from ...utils.logger import get_logger
from .configuration_llava import AraLlavaConfig
import logging

logger = get_logger(__name__)
logging.basicConfig(level=logging.DEBUG)


class AraLlavaForConditionalGeneration(AraModelForVisualCausalLM):
    
    config_class = AraLlavaConfig
    
    def __init__(
        self,
        session: DVSession,
        model: DVModel,
        endpoint: dvapi.dv_endpoint,
        model_path: Union[Path, str],
        config: AraLlavaConfig,
        generation_config: Optional[GenerationConfig] = None,
        **kwargs,
    ):
        super().__init__(
            session=session,
            model=model,
            endpoint=endpoint,
            model_path=model_path,
            config=config,
            generation_config=generation_config,
            **kwargs,
        )
        
        self.llm_model = model
        self.vision_model = None
        
        if model_path:
            self._load_processor()
            self._load_quantization_constants()
            self._load_embedding_table()
            
            vision_model_path = config.ara.vision_model_path
            if vision_model_path:
                logger.info(f"Loading vision model from: {vision_model_path}")
                ret, self.vision_model = session.load_model_from_file(endpoint, vision_model_path)
                if ret != dv_status_code.DV_SUCCESS:
                    logger.warning(f"Could not load vision model: {dvapi.dv_stringify_status_code(ret)}")
                else:
                    logger.info("Vision model loaded successfully")
    
    def _load_processor(self):
        try:
            self.processor = LlavaProcessor.from_pretrained(
                self.model_path, 
                local_files_only=True
            )
        except Exception as e:
            logger.warning(f"Could not load processor from {self.model_path}: {e}")
    
    def _load_quantization_constants(self):
        assets_dir = self.model_path / "assets"
        self.quantization_constants = []
        
        for i in range(1, 6):
            const_path = assets_dir / f"proxy_ip_data{i}.bin"
            if const_path.exists():
                const_data = np.fromfile(const_path, dtype=np.int8)
                self.quantization_constants.append(const_data)
            else:
                logger.warning(f"Quantization constant {i} not found at {const_path}")
                self.quantization_constants.append(np.zeros(1024, dtype=np.int8))
    
    def _load_embedding_table(self):
        embedding_path = self.model_path / self.config.embedding_table_path
        if not embedding_path.exists():
            raise FileNotFoundError(f"Embedding table not found at {embedding_path}")
        
        self.embedding = torch.nn.Embedding(self.config.num_total_tokens, self.config.num_embeddings_per_token).to(self.device)
        self.embedding.weight.data = torch.load(
            embedding_path,
            map_location=torch.device("cpu"),
            weights_only=True,
        ).to(self.device)
    
    def _encode_image(self, image: Union[Image.Image, np.ndarray]) -> torch.Tensor:
        if self.vision_model is None:
            raise RuntimeError("Vision model not loaded")
        
        if isinstance(image, Image.Image):
            image = to_numpy_array(image)
        
        pixel_values_inflated = image.astype(np.int8)
        
        embedding_output = np.zeros(1 * 576 * 4096, dtype=np.int8)
        embedding_output_scale = np.zeros(1 * 576 * 64, dtype=np.int8)
        
        success = self._do_vision_encoding_mm_projection(
            pixel_values_inflated=pixel_values_inflated,
            const_np_arrays=self.quantization_constants,
            outputs=[embedding_output, embedding_output_scale]
        )
        
        if not success:
            raise RuntimeError("Vision encoding failed")
        
        image_features = dequantize(
            scales=embedding_output_scale, 
            quantized=embedding_output, 
            shape=(1, 576, 4096)
        )
        return image_features
    
    def _do_vision_encoding_mm_projection(self, pixel_values_inflated: np.ndarray, const_np_arrays: list, outputs: list) -> bool:
        if self.vision_model is None:
            logger.error("Vision model not loaded")
            return False
        
        input_tensors = []
        ip_ids_embedded_tensor = dvapi.DVTensor(pixel_values_inflated, params=None)
        input_tensors.append(ip_ids_embedded_tensor)
        for ip in const_np_arrays:
            input_tensors.append(dvapi.DVTensor(ip, params=None))
        
        output_tensors = []
        for op in outputs:
            output_tensors.append(dvapi.DVTensor(op, params=None))
        
        ret, inf_req_obj = self.vision_model.infer_sync(
            input_tensors=input_tensors,
            output_tensors=output_tensors,
            endpoint=self.endpoint,
            timeout=20000
        )
        
        if ret != dv_status_code.DV_SUCCESS:
            logger.error("Infer failed for vision encoding")
            return False
        
        return True
    

    
    def get_embeddings(self, ids: torch.LongTensor) -> torch.Tensor:
        return self.embedding(ids)
    

    
 