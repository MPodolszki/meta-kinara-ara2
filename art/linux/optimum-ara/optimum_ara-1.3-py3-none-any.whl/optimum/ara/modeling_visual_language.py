# Copyright (c) 2025, Kinara, Inc. All rights reserved.
import os
from pathlib import Path
from typing import Optional, Union, Dict, Any

import numpy as np
import torch
from PIL import Image
from transformers import GenerationConfig
from transformers.image_utils import get_image_size, to_numpy_array

from .modeling_decoder import AraModelForCausalLM
from .api.dvapi import DVSession
from .utils.logger import get_logger

logger = get_logger(__name__)


def quantize(tensor: torch.Tensor, name: str = "", dump: bool = False) -> tuple[np.ndarray, np.ndarray]:
    """
    Quantize tensor to int8 format.
    Returns: (quantized_array, scales_array)
    """
    numpy_array = tensor.clone().cpu().detach().numpy()
    # calculate scale per each group of 64 elements as 7 - log2(max(abs(group)))
    grouped = numpy_array.reshape((int(numpy_array.size / 64)), 64)
    absolute_values = np.abs(grouped)
    max_values_group = np.max(absolute_values, axis=1)
    log_max_group = np.log2(max_values_group)
    scales = np.floor(log_max_group) + 1
    scales = 7 - scales
    scales = scales.astype(np.int8)
    if dump:
        scales.tofile(f"{name}_scale.bin")
    # scale each group by 2**scale
    scales = scales.reshape(-1, 1)
    scaled_array = np.floor(grouped * (np.float_power(2, scales.astype(np.int32))) + 0.5)
    scaled_array = np.clip(scaled_array, -128, 127).astype(np.int8)
    if dump:
        scaled_array.tofile(f"{name}.bin")
    return (scaled_array.flatten(), scales.flatten())


def dequantize(quantized: np.ndarray, scales: np.ndarray, shape: tuple) -> torch.Tensor:
    """Dequantize int8 array back to float tensor."""
    q_new = quantized.reshape(int(quantized.size / 64), 64)
    out = scales.reshape(-1, 1)
    q_new = q_new / np.float_power(2, out.astype(np.float16))
    return torch.from_numpy(q_new.reshape(shape))


class AraModelForVisualCausalLM(AraModelForCausalLM):
    """
    Base class for visual language models (LLaVA, Qwen-VL, etc.).

    Provides common functionality for vision-language models including:
    - Image processing and feature extraction
    - Vision-language fusion
    - Quantization utilities
    """

    def __init__(
        self,
        session,
        model_path: Union[Path, str],
        config,
        generation_config: Optional[GenerationConfig] = None,
        **kwargs,
    ):
        """
        Initialize visual language model.

        Args:
            session: Session for model management (LLaVASession, etc.)
            model_path: Path to the model directory
            config: Model configuration
            generation_config: Generation configuration
            **kwargs: Additional arguments
        """
        # Initialize base class with dummy session/model (we'll use session directly)
        super().__init__(
            session=None,  # We'll use session instead
            model=None,    # We'll use session's models
            endpoint=None, # We'll use session's endpoint
            model_path=model_path,
            config=config,
            generation_config=generation_config,
            **kwargs,
        )

        # Visual model initialization
        self.visual_session = session
        self.model_path = Path(model_path) if isinstance(model_path, str) else model_path
        self.config = config

        # Vision processing components
        self.processor = None  # Will be loaded from model_path
        self.image_embeddings_cached = None
        self.is_new_image = True
        self.processed_inputs = None
        self.is_image_updated = False

        # Load components
        self._load_processor()
        self._load_quantization_constants()
        self._load_embedding_table()

    def _load_processor(self):
        """Load the processor for the specific model type."""
        processor_path = self.model_path / "processor_config.json"
        if processor_path.exists():
            # This will be implemented by subclasses
            pass
        else:
            logger.warning(f"Processor config not found at {processor_path}")

    def _load_quantization_constants(self):
        """Load quantization constants if available."""
        # This will be implemented by subclasses if needed
        pass

    def _load_embedding_table(self):
        """Load the embedding table for token lookups."""
        # This will be implemented by subclasses if needed
        pass

    def _get_num_image_tokens(self, pixel_values):
        """Get the number of image tokens for the given pixel values."""
        # This will be implemented by subclasses
        raise NotImplementedError

    def process(self, image: Image, conversation: list, new_image: bool = True, **kwargs):
        """
        Process image and conversation for inference.

        Args:
            image: PIL Image to process
            conversation: Conversation turns for chat template
            new_image: Whether this is a new image
            **kwargs: Additional processing arguments
        """
        # This will be implemented by subclasses
        raise NotImplementedError

    def encode(self):
        """Encode the processed inputs."""
        # This will be implemented by subclasses
        raise NotImplementedError

    def _get_image_features(self, pixel_values: torch.Tensor) -> torch.Tensor:
        """
        Extract image features using the vision model.

        Args:
            pixel_values: Image pixel values

        Returns:
            Image features tensor
        """
        # This will be implemented by subclasses
        raise NotImplementedError

    def _merge_input_image_embeds(self, image_features: torch.Tensor, inputs_embeds: torch.Tensor) -> torch.Tensor:
        """
        Merge image features with input embeddings.

        Args:
            image_features: Image features tensor
            inputs_embeds: Input embeddings tensor

        Returns:
            Merged embeddings tensor
        """
        # This will be implemented by subclasses
        raise NotImplementedError

    def get_embeddings(self, ids: torch.LongTensor) -> torch.Tensor:
        """Get embeddings for token IDs."""
        # This will be implemented by subclasses
        raise NotImplementedError

    def generate(
        self,
        image: Optional[Image.Image] = None,
        conversation: Optional[list] = None,
        inputs: Optional[torch.Tensor] = None,
        input_ids: Optional[Union[torch.Tensor, list]] = None,
        pixel_values: Optional[torch.Tensor] = None,
        **kwargs,
    ):
        """
        Generate text based on image and/or text input.

        Args:
            image: PIL Image to process
            conversation: Conversation turns for chat template
            inputs: Pre-processed inputs (BatchFeature)
            input_ids: Token IDs
            pixel_values: Image pixel values
            **kwargs: Additional generation arguments

        Returns:
            Generated token IDs
        """
        if image is not None and conversation is not None:
            # Process image and conversation
            self.process(image, conversation, new_image=True)
            inputs_embeds = self.encode()
        elif inputs is not None:
            # Use pre-processed inputs
            self.processed_inputs = inputs
            inputs_embeds = self.encode()
        elif input_ids is not None and pixel_values is not None:
            # Use separate input_ids and pixel_values
            from transformers import BatchFeature
            self.processed_inputs = BatchFeature(data={
                "input_ids": input_ids,
                "pixel_values": pixel_values
            })
            inputs_embeds = self.encode()
        else:
            raise ValueError("Either (image, conversation), inputs, or (input_ids, pixel_values) must be provided")

        # Use parent class generation logic
        return super().generate(inputs_embeds=inputs_embeds, **kwargs)
