# Copyright (c) 2025, Kinara, Inc. All rights reserved.
import os
import sys
import importlib.util
from pathlib import Path

sdk_root = os.environ.get("DV_TGT_ROOT")
if not sdk_root:
    raise EnvironmentError("DV_TGT_ROOT environment variable not set")

# Path to external dvapi.py
dvapi_path = Path(sdk_root) / "art" / "linux" / "x86" / "include" / "dvapi.py"

if not dvapi_path.exists():
    raise FileNotFoundError(f"dvapi.py not found at {dvapi_path}")

# Dynamically load dvapi.py as optimum.ara.api.dvapi
spec = importlib.util.spec_from_file_location(
    "optimum.ara.api.dvapi", dvapi_path
)
dvapi_module = importlib.util.module_from_spec(spec)
sys.modules["optimum.ara.api.dvapi"] = dvapi_module
spec.loader.exec_module(dvapi_module)
