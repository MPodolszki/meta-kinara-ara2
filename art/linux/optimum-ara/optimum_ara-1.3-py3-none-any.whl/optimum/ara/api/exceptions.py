# Copyright (c) 2025, Kinara, Inc. All rights reserved.


class DvApiException(BaseException):
    def __init__(self, *args: object) -> None:
        super().__init__(*args)


# class DvApiModelLoadExcception(BaseException):
#     def __init__(self, message):
