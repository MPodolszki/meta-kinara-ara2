# Copyright (c) 2025, Kinara, Inc. All rights reserved.

import logging
from abc import ABC
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
import ctypes as c

from transformers import AutoConfig, AutoModel
from transformers.generation import GenerationMixin

from .api import dvapi
from .api.dvapi import DVEndpoint, DVModel, DVSession, dv_status_code
from .api.exceptions import DvApiException
from .configuration_utils import AraConfig, AraPretrainedConfig, InterfaceType
from .generation.configuration_utils import AraGenerationConfig

np.set_printoptions(threshold=5000)


class PreTrainedModel(ABC):
    """
    Abstract base class for all pre-trained models in the Ara framework.
    Used for compatibility with HuggingFace pipelines.
    """
    pass


class AraModel(PreTrainedModel):
    """
    Base class for all Ara models.

    This class provides the core logic for session and endpoint management,
    and utility functions for inference and generation. It is designed to be extended
    by specific model implementations (e.g., AraModelForCausalLM).
    """

    model_type = "ara_model"
    auto_model_class = AutoModel
    config_class = AutoConfig

    def __init__(
        self,
        session: DVSession,
        model: DVModel,
        endpoint: dvapi.dv_endpoint,
        model_path: Union[Path, str],
        config: "AraPretrainedConfig",
        preprocessors: Optional[List] = None,
    ):
        """
        Initialize the AraModel.

        Args:
            session (DVSession): The DVSession object for model execution.
            model (DVModel): The loaded DVModel object.
            endpoint (dvapi.dv_endpoint): The endpoint for inference.
            model_path (Union[Path, str]): Path to the model file.
            config (AraPretrainedConfig): Model configuration.
            preprocessors (Optional[List]): List of preprocessors to apply.
        """
        super().__init__()
        self.config = config
        self.session = session
        self.model = model
        self.endpoint = endpoint
        self.preprocessors = preprocessors

        self.num_outputs = model.num_outputs
        self.num_inputs = model.num_inputs

        self.model_path = (
            Path(model_path) if isinstance(model_path, str) else model_path
        )
        self.model_name = self.model_path.name
        self.device = "cpu"

    def __call__(self, *args, **kwargs):
        self.forward(*args, **kwargs)

    def __del__(self):
        assert self.session is not None
        assert self.model is not None
        if self.model is not None:
            self.model.__del__()
        if self.session is not None:
            self.session.__del__()

    def forward(
        self,
        input_ids: np.ndarray,
        output_ids: np.ndarray,
        active_tokens: int,
        valid_tokens: int,
        infer_type,
        **kwargs,
    ) -> tuple[dv_status_code, Optional[c.POINTER(dvapi.dv_infer_request)]]:
        endpoint = self.endpoint

        input_tensors = [dvapi.DVTensor(input_ids, params=None)]
        output_tensors = [dvapi.DVTensor(output_ids, params=None)]

        infer_options: dvapi.DVInferOptions = dvapi.DVInferOptions.dv_infer_options(
            enable_stats=True,
            infer_type=infer_type,
            active_tokens=active_tokens,
            valid_tokens=valid_tokens,
            tokens_to_skip=0,
        )

        status, inf_req = self.model.infer_sync_with_options(
            input_tensors=input_tensors,
            output_tensors=output_tensors,
            endpoint=endpoint._endpoint,
            timeout_ms=20000,
            infer_options=infer_options,
        )
        return status, inf_req

    @classmethod
    def from_pretrained(
        cls,
        *args,
        **kwargs,
    ) -> "AraModel":
        raise NotImplementedError

    def _prepare_output_buffer(self, model, output_shape: Tuple[int], output_name: str):
        raise NotImplementedError

    def _output_shape_inference(
        self, axis_name: Union[str, int], dimensions: Dict[str, int]
    ) -> Union[str, int]:
        raise NotImplementedError

    def can_generate(self) -> bool:
        """
        Returns whether this model can generate sequences with `.generate()`.
        """
        return isinstance(self, GenerationMixin)

    @classmethod
    def _load_model(
        cls,
        model_path: Union[str, Path],
        config: AraConfig,
        session: DVSession,
        endpoint: dvapi.dv_endpoint,
        generation_config: Optional[AraGenerationConfig] = None,
    ) -> DVModel:
        """
        Loads a model from file using the provided session and endpoint.

        Args:
            model_path (Union[str, Path]): Path to the model file.
            config (AraConfig): Model configuration.
            session (DVSession): DVSession object.
            endpoint (dvapi.dv_endpoint): Endpoint for inference.
            generation_config (Optional[AraGenerationConfig]): Generation configuration.

        Returns:
            DVModel: Loaded model object.

        Raises:
            DvApiException: If model loading fails.
        """
        if isinstance(model_path, Path):
            model_path = str(model_path)

        ret, model = session.load_model_from_file(endpoint, model_path)
        ret = None
        if ret != dvapi.dv_status_code.DV_SUCCESS:
            raise DvApiException(
                f"Could not load model: {dvapi.dv_stringify_status_code(ret)}"
            )

        assert model is not None
        return model

    @classmethod
    def load_model(
        cls,
        path: Union[str, Path],
        config: AraConfig,
        generation_config: Optional["AraGenerationConfig"] = None,
        # session_options: dvapi.dv_session_options,
    ) -> tuple[DVSession, DVEndpoint, DVModel]:
        """
        Instantiates an Ara inference session and loads a model using a .dvm file.

        Args:
            path (Union[str, Path]): Path to the model file.
            config (AraConfig): Model configuration.
            generation_config (Optional[AraGenerationConfig]): Generation configuration.

        Returns:
            tuple[DVSession, DVEndpoint, DVModel]: The session, endpoint, and loaded model.

        Raises:
            ValueError: If the interface type is unsupported.
            DvApiException: If session or endpoint creation fails.
        """
        # ToDO: Add code for creating session with named_pipe here.
        if config.interface_type == InterfaceType.SOCKET:
            ret, session = DVSession.create_via_unix_socket(
                config.interface_socket_file
            )
        elif config.interface_type == InterfaceType.IPV4:
            ip = config.interface_ip_address
            port = config.interface_port
            ret, session = DVSession.create_via_tcp_ipv4_socket(ip, port)
        else:
            raise ValueError(f"Unsupported interface type: {config.interface_type}")

        if ret != dvapi.dv_status_code.DV_SUCCESS:
            logging.error("could not establish session")
            raise DvApiException(
                f"Could not create session: {dvapi.dv_stringify_status_code(ret)}"
            )

        assert session is not None

        # get endpoint list
        ret, eplist = session.get_endpoint_list()

        if ret != dv_status_code.DV_SUCCESS:
            logging.error("could not get eplist")
            raise DvApiException(
                f"Could not load endpoints: {dvapi.dv_stringify_status_code(ret)}"
            )

        assert eplist is not None
        endpoint = eplist[0]

        # load model
        model = cls._load_model(path, config, session, endpoint, generation_config)

        return session, endpoint, model

    def to(self, device):
        """
        Workaround to bypass setting model device in pipeline
        """
        return self
