# Copyright (c) 2025, Kinara, Inc. All rights reserved.
# Copyright 2025-2026 NXP
# SPDX-License-Identifier: Apache-2.0

import os
import logging
import time
from pathlib import Path
from typing import Optional, Union, Any
from time import perf_counter

import numpy as np
import torch
from typing import Optional, Union, Any, cast, Dict, Tuple
from transformers import GenerationConfig, PretrainedConfig
from transformers.generation.logits_process import LogitsProcessorList
from transformers.generation.stopping_criteria import StoppingCriteriaList
from transformers.utils.generic import ModelOutput
from transformers.generation.streamers import BaseStreamer

from .configuration_utils import AraConfig, AraPretrainedConfig, InterfaceType
from .generation.configuration_utils import AraGenerationConfig
from .generation import CustomLogitsProcessor
from .modeling_decoder import AraModelForCausalLM
from .utils.constants import DEFAULT_GENERATION_CONFIG_NAME
from .utils.utils import dequantize, quantize

# Configure logging
logging.getLogger("urllib3").setLevel(logging.WARNING)
logging.getLogger("transformers").setLevel(logging.WARNING)
logging.getLogger("huggingface_hub").setLevel(logging.WARNING)
logging.getLogger("qwen_vl_utils").setLevel(logging.WARNING)
logging.getLogger("PIL").setLevel(logging.WARNING)
logging.getLogger("torchvision").setLevel(logging.WARNING)


class AraModelForVisualCausalLM(AraModelForCausalLM):
    """
    Base class for visual language models (LLaVA, Qwen-VL, etc.).

    Provides common functionality for vision-language models including:
    - Image processing and feature extraction
    - Vision-language fusion
    - Quantization utilities
    """

    NUM_TKNS_PER_FRAME: int = 0

    def __init__(
        self,
        model_path: Union[Path, str],
        config,
        **kwargs,
    ):
        """
        Initialize visual language model.

        Args:
            session: Session for model management (LLaVASession, etc.)
            model_path: Path to the model directory
            config: Model configuration
            **kwargs: Additional arguments
        """
        self.is_image_model = kwargs.get("is_image_model", False)
        super().__init__(
            model_path=model_path,
            config=config,
            **kwargs,
        )
        self._token_generation_time: float = 0.0
        self._ttft: float = 0.0
        self._generated_tokens_count: int = 0

        self._token_generation_time: float = 0.0
        self._ttft: float = 0.0
        self._generated_tokens_count: int = 0

    def load_components(self):
        # Load components
        self._load_quantization_constants()
        # Load embeddings
        self._load_embedding_table(self.dvm_path)
        self._load_vision_model_inputs()

    @classmethod
    def from_pretrained(
        cls,
        pretrained_model_name_or_path: Union[str, Path, os.PathLike],
        config: Optional[Union[PretrainedConfig, AraPretrainedConfig]] = None,
        *args,
        **kwargs,
    ) -> "AraModelForVisualCausalLM":
        """
        VLM-specific from_pretrained that loads both LLM and vision models.
        """

        use_cache = kwargs.pop("use_cache", True)
        file_name = kwargs.pop("file_name", None)

        # Load config using parent class method
        config_result = cls._get_config(
            pretrained_model_name_or_path, cast(Optional[AraPretrainedConfig], config)
        )
        if not isinstance(config_result, AraPretrainedConfig):
            raise TypeError(f"Expected AraPretrainedConfig, got {type(config_result)}")
        config_ara = config_result

        # Get LLM DVM path using parent class method
        llm_path = cls._get_llm_dvm_path(
            pretrained_model_name_or_path, config_ara, file_name
        )

        if config_ara.ara is None:
            raise ValueError("config.ara cannot be None")
        # Get vision DVM path using new method
        vision_path = cls._get_vision_dvm_path(config_ara)

        # Create VLM instance
        init_cls = cls(
            model_path=llm_path, config=config_ara, use_cache=use_cache, **kwargs
        )

        # VLM-specific: Load both LLM and vision models
        init_cls.load_model(str(llm_path))
        init_cls.load_vision_model(str(vision_path))
        init_cls.load_components()

        return init_cls

    @classmethod
    def _get_vision_dvm_path(cls, config: "AraPretrainedConfig"):
        if config is None:
            raise ValueError("config cannot be None")
        if config.ara is None:
            raise ValueError("config.ara cannot be None")
        vision_path = ""
        if hasattr(config.ara, "vision_model_path"):
            vision_model_path = config.ara.vision_model_path
            if (
                vision_model_path is not None
                and os.path.exists(str(vision_model_path))
                and str(vision_model_path).endswith(".dvm")
            ):
                vision_path = Path(vision_model_path)
            else:
                logging.warning(
                    f"incorrect vision model dvm file path provided in config {vision_model_path}"
                )
                logging.warning("vision_model_path should is a path to *.dvm file")
        else:
            logging.warning("'vision_model_path' is not present in config.ara")

        if vision_path == "":
            raise ValueError("Failed to find vision model dvm path")

        logging.info(f"Found vision dvm_file {vision_path}")
        return vision_path.resolve()

    def load_vision_model(self, model_path: str):
        """Load vision model from file."""
        ret = self.core.load_vision_model(str(model_path))

        return ret

    def _load_quantization_constants(self):
        """Load quantization constants if available."""
        # This will be implemented by subclasses if needed
        pass

    def _load_vision_model_inputs(self):
        """Load specific vision model inputs."""
        # This will be implemented by subclasses if needed
        pass

    def _get_num_image_tokens(self, pixel_values):
        """Get the number of image tokens for the given pixel values."""
        # This will be implemented by subclasses
        raise NotImplementedError

    def process(self, image, conversation: list, new_image: bool = True, **kwargs):
        """
        Process image and conversation for inference.

        Args:
            image: PIL Image to process
            conversation: Conversation turns for chat template
            new_image: Whether this is a new image
            **kwargs: Additional processing arguments
        """
        # This will be implemented by subclasses
        raise NotImplementedError

    def encode(self):
        """Encode the processed inputs."""
        # This will be implemented by subclasses
        raise NotImplementedError

    def _get_image_features(self, pixel_values: torch.Tensor) -> torch.Tensor:
        """
        Extract image features using the vision model.

        Args:
            pixel_values: Image pixel values

        Returns:
            Image features tensor
        """
        # This will be implemented by subclasses
        raise NotImplementedError

    def _merge_input_image_embeds(
        self, image_features: torch.Tensor, inputs_embeds: torch.Tensor
    ) -> torch.Tensor:
        """
        Merge image features with input embeddings.

        Args:
            image_features: Image features tensor
            inputs_embeds: Input embeddings tensor

        Returns:
            Merged embeddings tensor
        """
        # This will be implemented by subclasses
        raise NotImplementedError

    def get_embeddings(self, ids: torch.LongTensor) -> torch.Tensor:
        """Get embeddings for token IDs."""
        # This will be implemented by subclasses
        raise NotImplementedError

    def vision_inference(
        self, vision_inputs: torch.Tensor, num_frames: int
    ) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        """Perform vision inference."""
        # This will be implemented by subclasses
        raise NotImplementedError

    def merge_multi_modal_features(
        self,
        input_ids: torch.LongTensor,
        video_embeds: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
        input_embeds: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
    ) -> Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        """Merge multi-modal features."""
        # This will be implemented by subclasses
        raise NotImplementedError

    def forward(  # pyrefly: ignore[bad-override]
        self,
        input_ids: np.ndarray,
        output_ids: np.ndarray,
        active_tokens: int,
        valid_tokens: int,
        infer_type,
        tokens_to_skip: int = 0,
        **kwargs,
    ) -> tuple[Any, Optional[ModelOutput], float]:  # pyrefly: ignore
        """
        VLM-specific forward method that processes logits.
        Overrides the generic base class method to handle logits processing.
        """
        # Call the parent's forward method to get the raw inference
        status, inf_req, infer_time = self.core.forward(
            input_ids=input_ids,
            output_ids=output_ids,
            active_tokens=active_tokens,
            valid_tokens=valid_tokens,
            infer_type=infer_type,
            tokens_to_skip=tokens_to_skip,
            **kwargs,
        )
        status, inf_req = self.core.process_inference_output(
            status, output_ids, inf_req
        )
        return status, inf_req, infer_time

    def _generate_first_token(
        self,
        input_array: np.ndarray,
        output_array: np.ndarray,
        num_valid_tokens: int,
        num_active_tokens: int,
        generation_config: Optional[GenerationConfig] = None,
        **kwargs,
    ) -> Any:
        """
        Generates the first token using prompt processing.
        VLM-specific implementation with tokens_to_skip calculation.

        Args:
            input_array (np.ndarray): Input array.
            output_array (np.ndarray): Output array.
            num_valid_tokens (int): Number of valid tokens.
            num_active_tokens (int): Number of active tokens.

        Returns:
            dv_status_code: Status code of the inference.
        """

        # VLM-specific tokens_to_skip calculation
        # This should be overridden by specific VLM implementations
        tokens_to_skip = kwargs.pop("tokens_to_skip", 0)

        status, inf_req, infer_time = self.forward(
            input_array,
            output_array,
            infer_type=self.core.infer_type.DV_INFER_TYPE_LLM_PROMPT_PROCESSING,
            active_tokens=num_active_tokens,
            valid_tokens=num_valid_tokens,
            tokens_to_skip=tokens_to_skip,
        )

        return infer_time

    def _pad_until_vision_starts_at_multiple_of(
        self, input_ids: torch.Tensor, tkn_id: int, multiple: int = 128
    ):
        """
        Add padding to `input_ids` so that the first occurrence of a vision token id
            starts at an index that is a multiple of 128.
        This is done since the rope table only works when the vision token ids start
            at multiples of 128.
        """
        # Find first occurrence of tkn_id
        tkn_positions = (input_ids == tkn_id).nonzero(as_tuple=True)[0]
        if len(tkn_positions) == 0:
            return input_ids  # nothing to align

        first_idx = tkn_positions[0].item()

        # Compute required padding so first_idx aligns to multiple
        offset = first_idx % multiple
        pad = (multiple - offset) if offset != 0 else 0
        if pad > 0:
            pad_tensor = torch.full(
                (int(pad),),
                self.config.pad_token_id or 0,
                dtype=input_ids.dtype,
                device=input_ids.device,
            )
            input_ids = torch.cat((pad_tensor, input_ids), dim=0)

        return input_ids

    def generate(
        self,
        inputs: Optional[torch.Tensor] = None,
        generation_config: Optional[
            Union[GenerationConfig, AraGenerationConfig]
        ] = None,
        logits_processor: Optional[LogitsProcessorList] = None,
        stopping_criteria: Optional[StoppingCriteriaList] = None,
        prefix_allowed_tokens_fn: Optional[Any] = None,
        synced_gpus: Optional[bool] = None,
        assistant_model: Optional[Any] = None,
        streamer: Optional[BaseStreamer] = None,
        negative_prompt_ids: Optional[torch.Tensor] = None,
        negative_prompt_attention_mask: Optional[torch.Tensor] = None,
        use_model_defaults: Optional[bool] = None,
        custom_generate: Optional[str] = None,
        **kwargs,
    ) -> Union[torch.Tensor, Any]:
        """
        Generate text based on video and/or text input using custom generation loop.

        Args:
            inputs (Optional[torch.Tensor]): Input tensor.
            generation_config (Optional[Union[GenerationConfig, AraGenerationConfig]]): Generation configuration.
            logits_processor (Optional[LogitsProcessorList]): Custom logits processors.
            stopping_criteria (Optional[StoppingCriteriaList]): Custom stopping criteria.
            prefix_allowed_tokens_fn (Optional[Callable]): Function to constrain generation.
            synced_gpus (Optional[bool]): Whether to sync GPUs.
            assistant_model (Optional[Any]): Assistant model for speculative decoding.
            streamer (Optional[BaseStreamer]): Streamer for output tokens.
            negative_prompt_ids (Optional[torch.Tensor]): Negative prompt IDs.
            negative_prompt_attention_mask (Optional[torch.Tensor]): Negative prompt mask.
            **kwargs: Additional generation parameters (e.g., input_ids, pixel_values_videos, pixel_values).

        Returns:
            torch.Tensor: Generated sequences including input tokens, shape (batch_size, sequence_length)
        """
        self._ttft = 0
        self._token_generation_time = 0
        self._generated_tokens_count = 0

        input_ids = kwargs.pop("input_ids", None)
        pixel_values_videos = kwargs.pop("pixel_values_videos", None)
        pixel_values = kwargs.pop("pixel_values", None)

        if input_ids is not None:
            inputs = cast(torch.Tensor, input_ids)
        elif inputs is not None:
            input_ids = inputs
        else:
            raise ValueError("Either inputs or input_ids must be provided")

        # Validate inputs
        if input_ids is None:
            raise ValueError("input_ids must be provided")

        if pixel_values_videos is not None:
            num_frames = pixel_values_videos.shape[0] // (self.NUM_TKNS_PER_FRAME * 2)
        else:
            num_frames = 2
        if self.is_image_model and pixel_values_videos is not None:
            raise ValueError("This is an image model and won't work on video inputs")
        elif not self.is_image_model and pixel_values is not None:
            raise ValueError("This is a video model and won't work on image inputs")
        vision_inputs = pixel_values if self.is_image_model else pixel_values_videos
        if pixel_values is not None or pixel_values_videos is not None:
            vision_token_id = (
                self.config.image_token_id
                if self.is_image_model
                else self.config.video_token_id
            )
            input_ids = self._pad_until_vision_starts_at_multiple_of(
                cast(torch.Tensor, input_ids), vision_token_id
            )

        if generation_config is None:
            generation_config = AraGenerationConfig.from_model_config(
                self.config,
                target_token_post_mcp=0,
                target_token_pre_mcp=0,
                target_prompt_post_mcp=0,
                target_prompt_pre_mcp=0,
            )
            logging.info("Loading default Ara generation config object")

        # Update generation config with user parameters BEFORE setting up processors
        ara_generation_config, _ = self._prepare_generation_config(
            generation_config, **kwargs
        )
        self.core.update_llm_params(generation_config)
        self._ensure_generation_operators(ara_generation_config)

        start_time = perf_counter()

        # VLM-specific preprocessing
        if isinstance(input_ids, list):
            input_ids = torch.tensor(input_ids, dtype=torch.long)
        elif isinstance(input_ids, np.ndarray):
            input_ids = torch.from_numpy(input_ids).long()

        numpy_inputs = input_ids.detach().cpu().numpy().astype(np.int64)
        self._num_input_tokens = numpy_inputs
        num_max_tokens = self.core.get_max_num_tokens()
        eos_token_ls = (
            ara_generation_config.eos_token_id
            if isinstance(ara_generation_config.eos_token_id, list)
            else [ara_generation_config.eos_token_id]
        )
        if self.embedding is None or self.embedding_scales is None:
            raise ValueError("embedding or embedding_scales is None")
        input_embeds = (self.embedding(input_ids), self.embedding_scales(input_ids))
        if vision_inputs is not None:
            video_embeds = self.vision_inference(vision_inputs, num_frames)
        else:
            video_embeds = torch.tensor([])
        input_embeds = self.merge_multi_modal_features(
            input_ids, video_embeds, input_embeds
        )
        # Base type is Union[FloatTensor, Tuple[Tensor, Tensor]]; VLM passes (embeds, scales) tuple.
        prepared_inputs = self.prepare_inputs_for_generation(
            cast(torch.LongTensor, input_ids),
            inputs_embeds=cast(
                Optional[Union[torch.FloatTensor, Tuple[torch.Tensor, torch.Tensor]]],
                input_embeds,
            ),
            generation_config=ara_generation_config,
        )
        self.input_token_ids = numpy_inputs.flatten().astype(np.int64).copy()

        # Initialize generation variables
        input_array = prepared_inputs["input_array"]
        output_array = prepared_inputs["output_array"]

        generated_list = []
        num_tokens = numpy_inputs.size
        next_token_index = num_tokens
        active_tokens = num_tokens
        num_valid_tokens = num_tokens

        self.core.update_llm_params(generation_config)
        # Measure Time to First Token (TTFT)

        # First token generation using parent class method
        self._ttft = self._generate_first_token(
            input_array, output_array, active_tokens, num_valid_tokens
        )

        self._subsequent_start = time.time()

        # Generate first token using _extract_next_tokens
        input_ids_torch = torch.from_numpy(self.input_token_ids).long().unsqueeze(0)
        next_tokens = self._extract_next_tokens(
            output_array,
            self.input_token_ids,
            ara_generation_config,
            num_valid_tokens=1,
            is_first_token=True,
        )

        # Apply unfinished sequences logic
        unfinished_sequences = np.ones(1, dtype=np.float32)
        next_tokens = (
            next_tokens * unfinished_sequences
            + ara_generation_config.pad_token_id * (1 - unfinished_sequences)
        )
        # Update input token IDs for next iteration
        next_tokens = next_tokens.astype(np.int64)

        self.input_token_ids = np.concatenate(
            [
                self.input_token_ids.astype(np.int64),
                next_tokens.flatten().astype(np.int64),
            ]
        )
        generated_list.append(next_tokens[0])

        if streamer is not None:
            streamer.put(next_tokens.astype(np.int64))

        if generation_config.max_length > 0:
            user_max_length = generation_config.max_length + numpy_inputs.size
            if user_max_length > num_max_tokens:
                user_max_length = num_max_tokens
        else:
            user_max_length = num_max_tokens

        while True:
            if len(generated_list) + numpy_inputs.size >= num_max_tokens or any(
                token in eos_token_ls for token in next_tokens
            ):
                break
            next_tokens_tensor = torch.from_numpy(next_tokens[:, None]).long()
            if self.embedding is None:
                raise ValueError("embedding is None")
            embeds = self.embedding(next_tokens_tensor).flatten()
            if self.embedding_scales is None:
                raise ValueError("embedding_scales is None")
            embed_sclaes = self.embedding_scales(next_tokens_tensor).flatten()
            token_ids = next_tokens.astype(np.int32).view(np.int8)
            input_array = np.concatenate((token_ids, embeds, embed_sclaes))

            status, model_output, infer_time = self.forward(
                input_ids=input_array,
                output_ids=output_array,
                active_tokens=1,
                valid_tokens=1,
                infer_type=self.core.infer_type.DV_INFER_TYPE_LLM_TOKEN_GENERATION,
                tokens_to_skip=0,
            )

            self._token_generation_time += infer_time

            # Extract next tokens using _extract_next_tokens
            next_tokens = self._extract_next_tokens(
                output_array,
                self.input_token_ids,
                ara_generation_config,
                num_valid_tokens=1,
                is_first_token=False,
            )

            self.input_token_ids = np.concatenate(
                [self.input_token_ids, next_tokens.flatten()]
            )
            generated_list.append(next_tokens[0])

            if streamer is not None:
                streamer.put(next_tokens.astype(np.int64))

        if streamer is not None:
            streamer.end()
        generated_list = torch.tensor(generated_list, dtype=torch.int32)
        # Plus one for EOS token
        self._generated_tokens_count = len(generated_list) + 1

        return generated_list

    def __del__(self):
        super().__del__()
