# Copyright (c) 2025, Kinara, Inc. All rights reserved.
# Copyright 2025-2026 NXP
# SPDX-License-Identifier: Apache-2.0

from typing import ClassVar, Optional
from ...configuration_utils import AraConfig, AraPretrainedConfig


class AraQwen2_5_VL(AraConfig):
    vision_model_path: str | None = None
    input_scale_path: str | None = None
    rope_table_path: str | None = None


class AraQwen2_5VLConfig(AraPretrainedConfig):
    model_type = "ara_qwen_vl"
    ara_class = AraQwen2_5_VL


class AraQwen2_5ImageConfig(AraPretrainedConfig):
    model_type = "ara_qwen_image"
    ara_class = AraQwen2_5_VL
