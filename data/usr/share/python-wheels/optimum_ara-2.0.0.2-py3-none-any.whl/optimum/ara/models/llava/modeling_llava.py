# Copyright (c) 2025, Kinara, Inc. All rights reserved.
# Copyright 2025-2026 NXP
# SPDX-License-Identifier: Apache-2.0

# pyrefly: ignore-errors
# LLaVA still uses legacy dvapi/model/endpoint; dvapi is loaded at runtime.

import os
import warnings
from pathlib import Path
from typing import Optional, Union, Any, cast, Dict, Tuple, List

import numpy as np
import torch

from ...modeling_visual_language import AraModelForVisualCausalLM
from ...api import dvapi
from ...api.dvapi import dv_status_code, DVModel
from .configuration_llava import AraLlavaConfig
from ...utils.utils import dequantize, quantize
from ...generation.configuration_utils import AraGenerationConfig


class AraLlavaForConditionalGeneration(AraModelForVisualCausalLM):
    config_class = AraLlavaConfig

    def __init__(self, *args, **kwargs) -> None:
        # LLaVA is an image model, not a video model
        # Override any user-provided value to ensure it's always True
        is_image_model = kwargs.pop("is_image_model", True)
        # Number of image tokens - will be computed dynamically from vision output
        self._num_image_tokens: Optional[int] = None
        super().__init__(*args, **kwargs, is_image_model=True)

    def _load_quantization_constants(self):
        """Load vision model quantization constants from config-based paths."""
        self.quantization_constants = []

        # Load vision model quantization constants in the order expected by the DVM
        qc_paths = [
            getattr(self.config.ara, "vision_input_path", None),
            getattr(self.config.ara, "vision_input_scale_path", None),
            getattr(self.config.ara, "vision_add_input_path", None),
            getattr(self.config.ara, "vision_add_input_scale_path", None),
            getattr(self.config.ara, "vision_concat_input_path", None),
            getattr(self.config.ara, "vision_concat_input_scale_path", None),
        ]

        # Load constants from paths
        for i, path in enumerate(qc_paths):
            if path is None:
                continue
            const_path = Path(path)
            if not const_path.is_absolute():
                const_path = (Path(self.model_path).parent / const_path).resolve()
            if const_path.exists():
                self.quantization_constants.append(
                    np.fromfile(const_path, dtype=np.int8)
                )
            else:
                # Warn but don't fail - some models may not need all constants
                warnings.warn(
                    f"Vision quantization constant {i} file not found: {const_path}",
                    UserWarning,
                )

    def _load_embedding_table1(self):
        """Load embedding table - uses same pattern as Qwen-VL but with relative path support."""
        # Get embedding path (supports relative paths unlike Qwen-VL)
        # Require embedding_table_path to be specified in config - no hardcoded fallback
        if not (
            hasattr(self.config.ara, "embedding_table_path")
            and self.config.ara.embedding_table_path
        ):
            raise ValueError(
                "embedding_table_path must be specified in config.ara.embedding_table_path"
            )
        embedding_path = Path(self.config.ara.embedding_table_path)
        if not embedding_path.is_absolute():
            embedding_path = (Path(self.model_path).parent / embedding_path).resolve()

        if not embedding_path.exists():
            raise FileNotFoundError(f"Embedding table not found at {embedding_path}")

        # Use llm_params values (same as Qwen-VL) instead of config values
        self.embedding = torch.nn.Embedding(
            self.model._model.llm_params.contents.vocab_size,
            self.model._model.llm_params.contents.embedding_size,
        ).to(self.device)

        if self.embedding is None:
            raise ValueError("Failed to create embedding")

        self.embedding.weight.data = torch.load(
            embedding_path,
            map_location=torch.device("cpu"),
            weights_only=True,
        ).to(self.device)

    def _vision_inference(self, pixel_values_inflated: np.ndarray) -> list:
        if self.vision_model is None:
            raise ValueError("vision_model is None")
        input_tensors = []
        input_tensors.append(dvapi.DVTensor(pixel_values_inflated, params=None))
        for const_array in self.quantization_constants:
            input_tensors.append(dvapi.DVTensor(const_array, params=None))

        # Use llm_params values instead of hardcoded constants
        llm_params = self.model._model.llm_params.contents
        embedding_size = llm_params.embedding_size

        # Get number of image tokens - use cached value if available, otherwise from config
        # This will be computed dynamically on first inference if not set
        if self._num_image_tokens is None:
            # Try to get from config first
            if (
                hasattr(self.config, "num_image_tokens")
                and self.config.num_image_tokens
            ):
                self._num_image_tokens = self.config.num_image_tokens
            else:
                # For first inference, we need an estimate - use a reasonable default
                # This will be corrected after first inference based on actual output size
                # Standard LLaVA uses 576 (24x24 patches), but this varies by model size
                self._num_image_tokens = 576

        embedding_output = np.empty(
            self._num_image_tokens * embedding_size, dtype=np.int8
        )
        embedding_output_scale = np.empty(
            self._num_image_tokens * (embedding_size // 64), dtype=np.int8
        )
        outputs = [embedding_output, embedding_output_scale]

        output_tensors = []
        for op in outputs:
            output_tensors.append(dvapi.DVTensor(op, params=None))

        if self.vision_model is None:
            raise ValueError("vision_model is None")

        ret, inf_req = cast(DVModel, self.vision_model).infer_sync(
            input_tensors=input_tensors,
            output_tensors=output_tensors,
            endpoint=self.endpoint,
            timeout=20000,
        )

        if ret != dvapi.dv_status_code.DV_SUCCESS:
            return []

        return outputs

    def vision_inference(
        self, vision_inputs: torch.Tensor, num_frames: int
    ) -> torch.Tensor:
        if self.vision_model is None:
            raise RuntimeError("Vision model not loaded")

        # Handle both LLaVA (4D) and LLaVA-Next (5D)
        if vision_inputs.dim() == 5:
            vision_inputs = vision_inputs[:, 0, :, :, :]

        pixel_values_np = (
            np.clip((vision_inputs.numpy() * 32).astype(np.float16), -128, 127)
            .astype(np.int8)
            .flatten()
        )

        outputs = self._vision_inference(pixel_values_np)
        if not outputs:
            raise RuntimeError("Vision encoding failed")

        # Use llm_params values instead of hardcoded constants
        llm_params = self.model._model.llm_params.contents
        embedding_size = llm_params.embedding_size

        # Compute number of image tokens dynamically from actual output size
        # This ensures we use the correct value for different LLaVA model sizes
        output_size = outputs[0].size
        num_image_tokens = output_size // embedding_size

        # Cache the computed value for future use in _vision_inference
        if self._num_image_tokens != num_image_tokens:
            self._num_image_tokens = num_image_tokens

        image_features = dequantize(
            scales=outputs[1],
            quantized=outputs[0],
            shape=(1, num_image_tokens, embedding_size),
        )

        return image_features

    def merge_multi_modal_features(
        self,
        input_ids: torch.LongTensor,
        video_embeds: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
        input_embeds: Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]],
    ) -> torch.Tensor:
        image_token_index = getattr(self.config, "image_token_index", 32000)

        video_embeds_val = cast(torch.Tensor, video_embeds)
        input_embeds_val = cast(torch.Tensor, input_embeds)

        n_image_tokens = (input_ids == image_token_index).sum().item()
        n_image_features = video_embeds_val.shape[0] * video_embeds_val.shape[1]

        if n_image_tokens != n_image_features:
            raise ValueError(
                f"Image features and image tokens do not match: "
                f"tokens: {n_image_tokens}, features: {n_image_features}"
            )

        mask = (
            (input_ids == image_token_index)
            .unsqueeze(-1)
            .expand_as(input_embeds_val)
            .to(input_embeds_val.device)
        )
        video_embeds_val = video_embeds_val.to(
            input_embeds_val.device, input_embeds_val.dtype
        )
        merged_embeds = input_embeds_val.masked_scatter(mask, video_embeds_val)

        return merged_embeds

    def get_embeddings(self, ids: torch.LongTensor) -> torch.Tensor:
        if self.embedding is None:
            raise ValueError("embedding is None")
        return self.embedding(ids)

    def prepare_inputs_for_generation(
        self,
        input_ids: Union[torch.LongTensor, np.ndarray],
        past_key_values: Optional[Any] = None,
        attention_mask: Optional[torch.LongTensor] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        cache_position: Optional[torch.LongTensor] = None,
        generation_config: Optional[AraGenerationConfig] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Prepare input/output arrays in the same format used by the generic VLM path
        (tokens + embeddings + embedding scales), matching the Qwen-VL implementation.
        """
        if inputs_embeds is None:
            raise ValueError("inputs_embeds must be provided for LLaVA")

        llm_params_obj = self.model._model.llm_params.contents
        num_max_tokens = llm_params_obj.max_num_tokens
        embedding_dim = llm_params_obj.embedding_size

        # Number of valid prompt tokens before padding
        valid_tokens = inputs_embeds.shape[1]

        # Pad embeddings to max sequence length
        input_embeds_padded = torch.nn.functional.pad(
            inputs_embeds,
            (0, 0, 0, num_max_tokens - valid_tokens),
            value=0,
        )
        assert input_embeds_padded.shape == (
            1,
            num_max_tokens,
            embedding_dim,
        ), (
            f"Expected (1, {num_max_tokens}, {embedding_dim}), got {input_embeds_padded.shape}"
        )

        # Quantize embeddings
        input_embeds_float32 = input_embeds_padded.float()
        embedding, embedding_scales = quantize(input_embeds_float32)

        # Pad token ids to max length and view as int8 for packing
        input_ids_torch = torch.as_tensor(input_ids).long()
        token_ids = (
            torch.nn.functional.pad(
                input_ids_torch.squeeze(0),
                (0, num_max_tokens - input_ids_torch.size(1)),
                value=self.config.pad_token_id or 0,
            )
            .numpy()
            .astype(np.int32)
            .view(np.int8)
        )

        # Final input buffer: tokens + embeddings + embedding scales
        input_array = np.concatenate((token_ids, embedding, embedding_scales))
        output_array = np.zeros(
            (llm_params_obj.vocab_size * 4),
            dtype=np.int32,
        )

        return {
            "input_array": input_array,
            "output_array": output_array,
        }
