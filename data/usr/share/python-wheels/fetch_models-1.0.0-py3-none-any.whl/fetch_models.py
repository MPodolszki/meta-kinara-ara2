#!/usr/bin/env python3

# Copyright 2026 NXP

# NXP Proprietary. This software is owned or controlled by NXP and may only be
# used strictly in accordance with the applicable license terms. By expressly
# accepting such terms or by downloading, installing, activating and/or
# otherwise using the software, you are agreeing that you have read, and that
# you agree to comply with and are bound by, such license terms. If you do not
# agree to be bound by the applicable license terms, then you may not retain,
# install, activate or otherwise use the software.

import argparse
import shutil
from pathlib import Path
from huggingface_hub import snapshot_download

# Mapping of repo_id to local directory
MODEL_DIRS = {
    "nxp/Qwen2.5-7B-Instruct-Ara240": "/usr/share/llm/Qwen2.5-7B-Instruct",
    "nxp/Qwen2.5-Coder-1.5B-Ara240": "/usr/share/llm/Qwen2.5-Coder-1.5B",
    "nxp/Qwen2.5-VL-7B-Instruct-Ara240": "/usr/share/llm/Qwen2.5-VL-7B-Instruct",
    # TODO: use a tmp dir. As new models are supported it is risky to have everything on
    # /usr/share/cnn.
    "nxp/YOLOv8": "/usr/share/cnn/"
}
def parse_yolov8(models_path: str, target_path: str) -> None:
    
    # Iterate over all .dvm files in the models_path
    for src_file in Path(models_path).iterdir():
        if src_file.suffix == '.dvm':
            # Extract model name without extension (e.g., yolov8l-seg from yolov8l-seg.dvm)
            model_name = src_file.stem

            # Determine category based on suffix
            if model_name.endswith('-seg'):
                category = 'segmentation'
            elif model_name.endswith('-pose'):
                category = 'pose'
            elif model_name.endswith('-face'):
                # Special case: yolov8n-face goes to detection
                category = 'detection'
            else:
                # Default: models without suffix go to detection
                category = 'detection'
            
            # Create target directory for this model: /usr/share/cnn/{category}/{model_name}
            model_dir = Path(target_path) / category / model_name
            model_dir.mkdir(parents=True, exist_ok=True)
            
            # Destination path
            dst_file = model_dir / 'model.dvm'
            
            # Move/rename the file
            shutil.move(src_file, dst_file)
            
            # Copy README.md and LICENSE files if they exist
            for extra_file in ['README.md', 'LICENSE.txt']:
                extra_file_path = Path(models_path) / extra_file
                if extra_file_path.exists():
                    shutil.copy(extra_file_path, model_dir / extra_file)

    # Clean up extra files from the models_path
    for extra_file in ['README.md', 'LICENSE.txt', '.cache', '.gitattributes']:
        extra_file_path = Path(models_path) / extra_file
        if not extra_file_path.exists():
            continue

        if extra_file_path.is_dir():
            shutil.rmtree(extra_file_path)
        else:
            extra_file_path.unlink()
def main():
    parser = argparse.ArgumentParser(description="Download models from Hugging Face Hub")
    parser.add_argument(
        "-l",
        "--list",
        action="store_true",
        help="List all available models and exit"
    )
    parser.add_argument(
        "--repo-id",
        type=str,
        choices=MODEL_DIRS.keys(),
        help="Repository ID to download (e.g., nxp/Qwen2.5-7B-Instruct)"
    )
    parser.add_argument(
        "--revision",
        type=str,
        default="r2.0.4",
        help="Model revision/version to download (default: r2.0.4)"
    )
    parser.add_argument(
        "--local-dir",
        type=str,
        help="Local directory to store the model (overrides default location)"
    )

    args = parser.parse_args()

    if args.list:
        print("Available models:")
        for repo_id in MODEL_DIRS.keys():
            print(f"  {repo_id}")
        return

    if not args.repo_id:
        parser.error("--repo-id is required when not using --list")

    local_dir = args.local_dir if args.local_dir else MODEL_DIRS.get(args.repo_id)

    if not local_dir:
        print(f"Unknown repository: {args.repo_id}")
        return

    print(f"Downloading {args.repo_id} to {local_dir}...")

    try:
        snapshot_download(
            repo_id=args.repo_id,
            local_dir=local_dir,
            revision=args.revision
        )
    except Exception as e:
        print(f"Error downloading model: {e}")
        return

    if args.repo_id == "nxp/YOLOv8":
        parse_yolov8(local_dir, local_dir)

    print(f"Download complete: {local_dir}")

if __name__ == "__main__":
    main()